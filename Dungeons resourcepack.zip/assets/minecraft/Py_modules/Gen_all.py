from map import *
from symbols import *
import sys

# unicode free uE00 - F8FF
#   · Negative spaces takes f800-f80f & f820-f82f

f = open('../font/default.json', 'w')
f.write("""
{
    "providers": [
""")

image = '-i' in sys.argv
map_all(f, image)
symbols(f)

f.write("""
        {
            "type": "ttf",
            "file": "minecraft:negative_spaces.ttf",
            "shift": [0.0, 0.0],
            "size": 10.0,
            "oversample": 1.0
        }
    ]
}""")
f.close()
