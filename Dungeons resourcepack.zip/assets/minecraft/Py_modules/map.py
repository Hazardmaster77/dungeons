import sys
import os
from PIL import Image

# ============================
#         --{ MAP }--
# ============================
def map_all(file, image = False):
    base = Image.open("map_base/32/7x7_marc.png")
    max_size = base.size
    slots = 7

    l   = ['n','s','e','w','spawn','enemy','armory','boss','item','player']
    # ------- Center make -----------
    if image:
        room = Image.open('map_base/32/center.png')
        x, y = room.size
        new_im = Image.new('RGBA', max_size)
        new_im.paste(room, (x*3+16, y*3+16))
        new_im.paste(base, (0,0), base)
        new_im.save('../textures/map/center.png')

    file.write(
    """
            {
                "type": "bitmap",
                "file": "minecraft:map/map_background.png",
                "ascent": 160,
                "height": 160,
                "chars": ["\\uE000"]
            },
            {
                "type": "bitmap",
                "file": "minecraft:map/center.png",
                "ascent": 160,
                "height": 160,
                "chars": ["\\uE001"]
            },""")

    # --------------- Rooms --------------
    unicode = 0xE002
    for i,variant in enumerate(l):
        p = '../textures/map/'+ variant
        if not os.path.exists(p):
            os.mkdir(p)
            print("Directory ", p , " Created ")

        if image:
            y_offset = 16
        for y_inc in range(slots):
            if image:
                x_offset = 16
            for x_inc in range(slots):
                # Image
                if image:
                    room = Image.open('map_base/32/' + variant + ".png")
                    new_im = Image.new('RGBA', max_size)
                    new_im.paste(room, (x_offset, y_offset))
                    new_im.paste(base, (0,0), base)
                    new_im.save("{0}/{1}{2}.png".format(p, y_inc, x_inc))
                    x_offset += x

                # default.json
                file.write("""
            {{
                "type": "bitmap",
                "file": "minecraft:map/{0}/{1}{2}.png",
                "ascent": 160,
                "height": 160,
                "chars": ["\\u{3:x}"]
            }},""".format(variant, y_inc, x_inc, unicode))

                unicode += 1

            if image:
                y_offset += y
