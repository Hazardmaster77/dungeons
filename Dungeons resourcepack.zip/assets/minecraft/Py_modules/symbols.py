def symbols(file):
    stats = [
            ("hp","\\uF810"),
            ("dmg","\\uF811"),
            ("attack_speed","\\uF812"),
            ("speed","\\uF813"),
            ("armor","\\uF814"),
            ("armor_thoughness","\\uF815"),
            ("knock_resist","\\uF816"),
            ("mana_capacity","\\uF817"),
            ("mana_speed","\\uF818"),
            ("mana_cost","\\uF819"),
            ("kills_capacity","\\uF81a"),
            ("luck","\\uF81b"),
            ("curse","\\uF81c")
        ]
    for stat in stats:
        file.write("""
            {{
                "type": "bitmap",
                "file": "minecraft:symbols/stats/{}.png",
                "ascent": 8,
                "height": 8,
                "chars": ["{}"]
            }},""".format(stat[0], stat[1]))

    file.write("""
        {
            "type": "bitmap",
            "file": "minecraft:symbols/coin.png",
            "ascent": 8,
            "height": 8,
            "chars": ["\\uF81d"]
        },""")
